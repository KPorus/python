
<pre> 
<i>'simple_scripts'</i> Sub-directory contains all simplest programs,
these programs are <strong>simple to read/write</strong>.
</pre>
The programs have been <strong>re-checked</strong> and <strong> improved a bit </strong> <br/>
Although i've tried to keep it as orignal as possible. <br/>
<b>Thanks</b>
