
<pre>
<i>'math'</i> Sub-directory contains all the math related scripts
<strong>This dir does not contain mathematical algorithms,
only math related scripts</strong> 
</pre>
The programs have been <strong>re-checked</strong> and <strong>re-mastered</strong> by me!<br>
Although i've tried to keep it as orignal as possible.<br>
Keep Patience It'll take time to go through every program!!<br>
<b>Thanks</b>
