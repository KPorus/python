list_of_even_squares = [num ** 2 for num in range(0,101,2)]
print(list_of_even_squares , "\n")

list_of_odd_squares = [num ** 2 for num in range(1,102,2)]
print(list_of_odd_squares , "\n")

list_of_even_cubes = [num ** 3 for num in range(0,101,2)]
print(list_of_even_cubes , "\n")

list_of_odd_cubes = [num ** 3 for num in range(1,102,2)]
print(list_of_odd_cubes , "\n")
