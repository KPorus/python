
<pre>
<i>'string'</i> Sub-directory contains all 
<strong>string related algorithms</strong>

<strong>Thanks</strong>
</pre>
