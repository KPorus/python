# Pythagoras Formula
import math
# a.sq + b.sq = c.sq

a = float(input('Value for A : '))
b = float(input('Value for B : '))
c = math.sqrt(a ** 2 + b ** 2)
# here's the answer
print(c)